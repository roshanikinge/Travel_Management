<div class="col-sm-12">
					
	<div class="header">
	
		<div class="col-sm-4">
	
		<div class="logo"></div>
		
	</div>
	
		<div class="col-sm-8">
	
		<div class="headerMenu">
			
			<ul>
				<a href="index.php"><li>Home</li></a>
				<a href="aboutUs.php"><li>About Us</li></a>
				<a href="userDashboardProfile.php"><li>Dashboard</li></a>
				<a href="logout.php"><li>Logout</li></a>
				<li class="active">Contact Us</li>
			</ul>
			
		</div>
	</div>
	
	</div> <!-- header -->
				
</div> <!-- col-sm-12 MENU -->